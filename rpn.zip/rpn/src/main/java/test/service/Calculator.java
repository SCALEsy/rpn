package test.service;

public interface Calculator {
    void add();

    void sub();

    void mul();

    void div();

    void sqrt();

    void undo();

    void clear();

    void push(Double v);
}
