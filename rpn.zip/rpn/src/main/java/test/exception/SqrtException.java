package test.exception;

public class SqrtException extends RuntimeException {
    public SqrtException(String msg) {
        super(msg);
    }
}
