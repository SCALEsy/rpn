package test.exception;

public class DivZeroException extends RuntimeException {
    public DivZeroException(String msg) {
        super(msg);
    }
}
