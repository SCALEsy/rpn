package test.exception;

public class UndoException extends RuntimeException {
    public UndoException(String msg) {
        super(msg);
    }
}
